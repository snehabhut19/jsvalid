function validateForm() {

 
    var name = document.forms["reg"]["name"].value;
    var email = document.forms["reg"]["email"].value;
    var password = document.forms["reg"]["password"].value;
    var conpass = document.forms["reg"]["conpass"].value;
    var address = document.forms["reg"]["address"].value;
    var gender = document.forms["reg"]["gender"].value;
    var phone = document.forms["reg"]["phone"].value;
    var city = document.forms["reg"]["city"].value;
    var file = document.forms["reg"]["file"].value;

    var email1=/^[a-zA-Z0-9_\.\-]+\@[a-zA-Z0-9\-]+\.[a-zA-Z]{2,4}$/;
    var phone1 =  /^\d{10}$/;
 
    var error = 0;
    document.getElementById("f").innerHTML = "";
    document.getElementById("e").innerHTML = "";
    document.getElementById("p").innerHTML = "";
    document.getElementById("cp").innerHTML = "";
    document.getElementById("a").innerHTML = "";
    document.getElementById("g").innerHTML = "";
    document.getElementById("ph").innerHTML = "";
    document.getElementById("ci").innerHTML = "";
    document.getElementById("fi").innerHTML = "";
    document.getElementById("h").innerHTML = "";

    if (name == "" || name == null) {
        error++;
        document.getElementById("f").innerHTML = "* Please enter the name";

    }

    if (email == "" || email == null) {
        error++;
        document.getElementById("e").innerHTML = "* Please enter the email";

    }
    else if(email1.test(email) == 0){
       error++;
       document.getElementById("e").innerHTML = "* Please enter the  valid email";
    
       }
    if (password == "" || password == null) {
        error++;
        document.getElementById("p").innerHTML = "* Please enter the password";

    }else if(password.length <6)
    {
        error++;
        document.getElementById("p").innerHTML = "* min 6 char are requried";

    }

    
    if (conpass == "" || conpass == null) {
        error++;
        document.getElementById("cp").innerHTML = "* Please enter the confirm password";

    }
    else if(conpass.length <6)
    {
        error++;
        document.getElementById("cp").innerHTML = "* min 6 char are requried";

    }
    else if (conpass != password) {
        error++;
        document.getElementById("cp").innerHTML = "* password is not match";


    }


    if (gender == "" || gender == null) {
        error++;
        document.getElementById("g").innerHTML = "* Please enter the gender";

    }

    if (phone == "" || phone == null) {
        error++;
        document.getElementById("ph").innerHTML = "* Please enter the phone";

    }

    if(phone1.test(phone) == 0){
        error++;
        document.getElementById("ph").innerHTML = "* only numbers are valid";
     
        }


    if (address == "" || address == null) {
        error++;
        document.getElementById("a").innerHTML = "* Please enter the address";

    }

    if (city == "select") {
        error++;
        document.getElementById("ci").innerHTML = "* Please enter the city";

    }

    var hobbies1 = document.getElementById("hobbies1").checked;
    var hobbies2 = document.getElementById("hobbies2").checked;

    if ((hobbies1 == "") && (hobbies2 == "")) {
        error++;
        document.getElementById("h").innerHTML = "* Please enter the hobbies";
        // firstname.focus();
    }


    if (file == "" || file == null) {
        error++;
        document.getElementById("fi").innerHTML = "* Please enter file";

    }
    if (error > 0) {
        return false;
    }

    return true;

}
var x = document.getElementById("conpass").disabled = true;

function undisablePsw() {
    var password = document.getElementById('password').value;

    if(password.length <= 0)
    {
    document.getElementById("conpass").disabled = true;
    }else{
    document.getElementById("conpass").disabled = false;
    }

}


$(document).on('keydown', '.check', function () {
    var answer = $(this).val();
    // console.log( $(this).parent());
    if (answer == "" ) {
        $(this).parent().find('.error').show();
        }else{
            $(this).parent().find('.error').hide();
        } 
});

    